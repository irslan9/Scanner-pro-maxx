package com.scannerpro.max

import android.graphics.Bitmap
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.Locale

/**
 * Writes a multi-page PDF where every page is one JPEG (DCTDecode).
 * Streams page by page, so memory stays low and file size follows the JPEG quality.
 */
object PdfWriter {
    private class Out(os: OutputStream) {
        val o = BufferedOutputStream(os)
        var n = 0L
        fun w(b: ByteArray) { o.write(b); n += b.size }
        fun w(s: String) = w(s.toByteArray(Charsets.ISO_8859_1))
    }

    fun write(os: OutputStream, count: Int, maxDim: Int, quality: Int, bitmap: (Int) -> Bitmap) {
        require(count > 0) { "Document has no pages" }
        val o = Out(os)
        val objs = 3 + 3 * count
        val off = LongArray(objs)
        o.w("%PDF-1.4\n")
        off[1] = o.n; o.w("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
        val kids = (0 until count).joinToString(" ") { "${3 + 3 * it} 0 R" }
        off[2] = o.n; o.w("2 0 obj\n<< /Type /Pages /Kids [$kids] /Count $count >>\nendobj\n")
        for (i in 0 until count) {
            val src = bitmap(i)
            val bmp = ImageProc.fit(src, maxDim)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, bos)
            val jpg = bos.toByteArray()
            val ph = String.format(Locale.US, "%.2f", 595f * bmp.height / bmp.width)
            val pn = 3 + 3 * i; val cn = pn + 1; val im = pn + 2
            off[pn] = o.n
            o.w("$pn 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 $ph] /Contents $cn 0 R /Resources << /XObject << /Im0 $im 0 R >> >> >>\nendobj\n")
            val content = "q 595 0 0 $ph 0 0 cm /Im0 Do Q"
            off[cn] = o.n
            o.w("$cn 0 obj\n<< /Length ${content.length} >>\nstream\n$content\nendstream\nendobj\n")
            off[im] = o.n
            o.w("$im 0 obj\n<< /Type /XObject /Subtype /Image /Width ${bmp.width} /Height ${bmp.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.size} >>\nstream\n")
            o.w(jpg)
            o.w("\nendstream\nendobj\n")
            if (bmp !== src) bmp.recycle()
            src.recycle()
        }
        val xr = o.n
        o.w("xref\n0 $objs\n0000000000 65535 f \n")
        for (n in 1 until objs) o.w(String.format(Locale.US, "%010d 00000 n \n", off[n]))
        o.w("trailer\n<< /Size $objs /Root 1 0 R >>\nstartxref\n$xr\n%%EOF\n")
        o.o.flush()
    }
}
