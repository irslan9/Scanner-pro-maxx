package com.scannerpro.max

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayView(c: Context) : View(c) {
    var pts: FloatArray? = null
    private val fill = Paint().apply { color = 0x442F6FDB; style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2F6FDB.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f * resources.displayMetrics.density }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val p = pts ?: return
        val ar = 3f / 4f
        var dw = width.toFloat(); var dh = dw / ar
        if (dh > height) { dh = height.toFloat(); dw = dh * ar }
        val ox = (width - dw) / 2; val oy = (height - dh) / 2
        path.reset()
        path.moveTo(ox + p[0] * dw, oy + p[1] * dh)
        for (i in 1..3) path.lineTo(ox + p[i * 2] * dw, oy + p[i * 2 + 1] * dh)
        path.close()
        canvas.drawPath(path, fill)
        canvas.drawPath(path, stroke)
    }
}

class ScanActivity : AppCompatActivity() {
    private var docId = 0L
    private var count = 0
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var counter: TextView
    private lateinit var hint: TextView
    private var capture: ImageCapture? = null
    private var camera: Camera? = null
    private var auto = true
    private var torch = false
    @Volatile private var busy = false
    private var stable = 0
    private var last: FloatArray? = null
    private var cooldown = 0L
    private var lastRun = 0L
    private val exec = Executors.newSingleThreadExecutor()

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else { toast("Camera permission is needed to scan"); finish() }
    }
    private val gallery = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) work("Importing…") {
            if (docId == 0L) docId = Repo.newDoc(this)
            uris.forEach { u -> ImageProc.decodeUri(contentResolver, u, 3000)?.let { Repo.addPage(this, docId, it); count++ } }
            counter.text = "$count"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        docId = intent.getLongExtra("docId", 0L)
        auto = Prefs.auto(this)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER; implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        overlay = OverlayView(this)
        val area = { FrameLayout.LayoutParams(-1, -1).apply { topMargin = dp(56); bottomMargin = dp(150) } }
        root.addView(preview, area())
        root.addView(overlay, area())

        // top bar
        val top = hbox().apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
        top.addView(label("✕", 22f, true, Color.WHITE).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { finish() } })
        hint = label("Point at a document", 14f, false, Color.WHITE).apply { gravity = Gravity.CENTER }
        top.addView(hint, lp(0, -2, 1f))
        val autoBtn = label(if (auto) "AUTO ON" else "AUTO OFF", 13f, true, Color.WHITE).apply { setPadding(dp(10), dp(8), dp(10), dp(8)) }
        autoBtn.setOnClickListener { auto = !auto; stable = 0; autoBtn.text = if (auto) "AUTO ON" else "AUTO OFF" }
        top.addView(autoBtn)
        val flash = label("⚡", 22f, true, Color.WHITE).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
        flash.setOnClickListener {
            torch = !torch; camera?.cameraControl?.enableTorch(torch)
            flash.setTextColor(if (torch) Color.YELLOW else Color.WHITE)
        }
        top.addView(flash)
        root.addView(top, FrameLayout.LayoutParams(-1, dp(56), Gravity.TOP))

        // bottom bar
        val bottom = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val gal = label("Gallery", 15f, true, Color.WHITE).apply { setPadding(dp(16), dp(16), dp(16), dp(16)); setOnClickListener { gallery.launch("image/*") } }
        bottom.addView(gal, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        val shutter = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(dp(5), C.LIGHT) }
            setOnClickListener { takePhoto() }
        }
        bottom.addView(shutter, FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER))
        val right = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        counter = label("0", 20f, true, Color.WHITE).apply { gravity = Gravity.CENTER }
        right.addView(counter)
        right.addView(button("Done") { finishScan() })
        bottom.addView(right, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bottom, FrameLayout.LayoutParams(-1, dp(150), Gravity.BOTTOM))
        setContentView(root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else perm.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val provider = fut.get()
            val prev = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            val an = ImageAnalysis.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            an.setAnalyzer(exec) { analyze(it) }
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, prev, capture, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastRun < 140 || busy) return
            lastRun = now
            val bmp = ImageProc.rotate(img.toBitmap(), img.imageInfo.rotationDegrees)
            val c = ImageProc.detectOrNull(bmp)
            val prev = last
            val moved = if (c != null && prev != null) (0..7).maxOf { abs(prev[it] - c[it]) } else 1f
            last = c
            stable = if (c != null && moved < 0.025f) stable + 1 else 0
            val fire = auto && stable >= 10 && now > cooldown
            if (fire) { stable = 0; cooldown = now + 2500 }
            runOnUiThread {
                overlay.pts = c; overlay.invalidate()
                hint.text = when { c == null -> "Point at a document"; auto -> "Hold steady…"; else -> "Tap the shutter" }
                if (fire) takePhoto()
            }
        } finally {
            img.close()
        }
    }

    private fun takePhoto() {
        val cap = capture ?: return
        if (busy) return
        busy = true
        val f = File(cacheDir, "cap_${System.currentTimeMillis()}.jpg")
        cap.takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    hint.text = "Processing…"
                    lifecycleScope.launch {
                        try {
                            val bmp = withContext(Dispatchers.IO) { ImageProc.decodeUpright(f, 3000) }
                            f.delete()
                            if (bmp != null) {
                                if (docId == 0L) docId = Repo.newDoc(this@ScanActivity)
                                Repo.addPage(this@ScanActivity, docId, bmp)
                                count++
                                counter.text = "$count"
                            }
                        } catch (e: Exception) {
                            toast("Error: ${e.message}")
                        } finally {
                            busy = false
                        }
                    }
                }

                override fun onError(e: ImageCaptureException) { busy = false; toast("Capture failed: ${e.message}") }
            })
    }

    private fun finishScan() {
        if (busy) return
        if (count == 0) { finish(); return }
        if (intent.getLongExtra("docId", 0L) == 0L) startActivity(Intent(this, DocActivity::class.java).putExtra("docId", docId))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdown()
    }
}
