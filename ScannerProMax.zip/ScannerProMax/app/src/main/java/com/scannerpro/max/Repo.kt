package com.scannerpro.max

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import cz.adaptech.tesseract4android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max

object Repo {
    fun dao(c: Context) = AppDb.get(c).dao()

    /** kind = raw | out | thumb. All files live in the app-private storage. */
    fun file(c: Context, pageId: Long, kind: String): File =
        File(File(c.filesDir, "pages").apply { mkdirs() }, "${pageId}_$kind.jpg")

    fun fmt(t: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(t))
    fun defaultName() = "Scan " + SimpleDateFormat("yyyy-MM-dd HH.mm", Locale.US).format(Date())
    fun safe(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "scan" }

    fun displayName(c: Context, u: Uri): String {
        c.contentResolver.query(u, null, null, null, null)?.use {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && it.moveToFirst()) return it.getString(i)
        }
        return u.lastPathSegment ?: "file"
    }

    fun size(c: Context, u: Uri): Long =
        c.contentResolver.openFileDescriptor(u, "r")?.use { it.statSize } ?: 0L

    fun human(b: Long): String = if (b >= 1 shl 20) String.format(Locale.US, "%.1f MB", b / 1048576.0) else "${b / 1024} KB"

    // ---------- documents & pages ----------
    suspend fun newDoc(c: Context, name: String = defaultName(), folder: Long = 0): Long = dao(c).insertDoc(Doc(name = name, folderId = folder))

    suspend fun addPage(c: Context, docId: Long, bmp: Bitmap, detect: Boolean = true, filter: String? = null): Long =
        withContext(Dispatchers.Default) {
            val d = dao(c)
            val src = ImageProc.fit(bmp, 3000)
            val corners = if (detect) ImageProc.detect(src).joinToString(",") else ""
            val p = Page(docId = docId, idx = d.pageCount(docId), filter = filter ?: Prefs.filter(c), corners = corners)
            val id = d.insertPage(p)
            FileOutputStream(file(c, id, "raw")).use { src.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            render(c, p.copy(id = id))
            id
        }

    /** Re-creates the processed image + thumbnail from the untouched original. */
    suspend fun render(c: Context, p: Page) = withContext(Dispatchers.Default) {
        val raw = ImageProc.decode(file(c, p.id, "raw"), 2200) ?: return@withContext
        val out = ImageProc.process(raw, p.corners, p.rotation, p.filter, p.brightness, 2200)
        FileOutputStream(file(c, p.id, "out")).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        val th = ImageProc.fit(out, 360)
        FileOutputStream(file(c, p.id, "thumb")).use { th.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        if (th !== out) th.recycle()
        if (out !== raw) out.recycle()
        raw.recycle()
    }

    suspend fun deletePage(c: Context, p: Page) = withContext(Dispatchers.IO) {
        listOf("raw", "out", "thumb").forEach { file(c, p.id, it).delete() }
        val d = dao(c)
        d.deletePage(p)
        d.pages(p.docId).forEachIndexed { i, q -> if (q.idx != i) d.updatePage(q.copy(idx = i)) }
    }

    suspend fun purgeDoc(c: Context, docId: Long) = withContext(Dispatchers.IO) {
        val d = dao(c)
        d.pages(docId).forEach { p -> listOf("raw", "out", "thumb").forEach { file(c, p.id, it).delete() }; d.deletePage(p) }
        d.doc(docId)?.let { d.deleteDoc(it) }
    }

    suspend fun mergeDocs(c: Context, ids: List<Long>, name: String): Long = withContext(Dispatchers.IO) {
        val d = dao(c)
        val nd = d.insertDoc(Doc(name = name))
        var idx = 0
        for (id in ids) for (p in d.pages(id)) {
            val np = d.insertPage(p.copy(id = 0, docId = nd, idx = idx++))
            for (k in listOf("raw", "out", "thumb")) {
                val s = file(c, p.id, k)
                if (s.exists()) s.copyTo(file(c, np, k), true)
            }
        }
        nd
    }

    suspend fun importPdf(c: Context, uri: Uri, docId: Long) = withContext(Dispatchers.Default) {
        val pfd = c.contentResolver.openFileDescriptor(uri, "r") ?: return@withContext
        val r = PdfRenderer(pfd)
        try {
            for (i in 0 until r.pageCount) {
                val pg = r.openPage(i)
                val sc = 1800f / max(pg.width, pg.height)
                val bmp = Bitmap.createBitmap(max(1, (pg.width * sc).toInt()), max(1, (pg.height * sc).toInt()), Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pg.close()
                addPage(c, docId, bmp, detect = false, filter = "ORIGINAL")
                bmp.recycle()
            }
        } finally {
            r.close(); pfd.close()
        }
    }

    // ---------- PDF export ----------
    /** quality: 0 = High, 1 = Medium, 2 = Low (smallest). */
    private val Q = arrayOf(2400 to 90, 1600 to 75, 1000 to 55)

    suspend fun exportPdf(c: Context, docId: Long, name: String, quality: Int): File = withContext(Dispatchers.Default) {
        val pages = dao(c).pages(docId)
        if (pages.isEmpty()) throw IllegalStateException("This document has no pages")
        val dir = File(c.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, safe(name) + ".pdf")
        val (md, q) = Q[quality.coerceIn(0, 2)]
        FileOutputStream(f).use {
            PdfWriter.write(it, pages.size, md, q) { i ->
                ImageProc.decode(file(c, pages[i].id, "out"), md)
                    ?: Bitmap.createBitmap(10, 10, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }
            }
        }
        f
    }

    suspend fun copyTo(c: Context, f: File, uri: Uri) = withContext(Dispatchers.IO) {
        c.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        Unit
    }

    /** Opens the Android share sheet (Gmail and any other installed email/share app). */
    fun send(c: Context, files: List<File>, email: Boolean, subject: String) {
        val uris = ArrayList(files.map { FileProvider.getUriForFile(c, "${c.packageName}.files", it) })
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = "application/pdf"
        i.putExtra(Intent.EXTRA_SUBJECT, subject)
        if (email) {
            val to = Prefs.email(c)
            if (to.isNotBlank()) i.putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            i.putExtra(Intent.EXTRA_TEXT, "Sent from Scanner Pro max")
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, if (email) "Send by email" else "Share PDF"))
    }

    // ---------- backup / restore (manual, local file) ----------
    suspend fun backup(c: Context, out: OutputStream) = withContext(Dispatchers.IO) {
        val d = dao(c)
        val m = JSONObject()
        m.put("folders", JSONArray().also { a -> d.folders().forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) } })
        m.put("docs", JSONArray().also { a ->
            d.allDocs().forEach {
                a.put(JSONObject().put("id", it.id).put("name", it.name).put("folderId", it.folderId).put("created", it.created)
                    .put("favorite", it.favorite).put("trashed", it.trashed).put("ocr", it.ocrText))
            }
        })
        val pages = d.allPages()
        m.put("pages", JSONArray().also { a ->
            pages.forEach {
                a.put(JSONObject().put("id", it.id).put("docId", it.docId).put("idx", it.idx).put("rotation", it.rotation)
                    .put("filter", it.filter).put("brightness", it.brightness).put("corners", it.corners))
            }
        })
        ZipOutputStream(out.buffered()).use { z ->
            z.putNextEntry(ZipEntry("manifest.json")); z.write(m.toString().toByteArray()); z.closeEntry()
            for (p in pages) {
                val f = file(c, p.id, "raw")
                if (!f.exists()) continue
                z.putNextEntry(ZipEntry("pages/${p.id}_raw.jpg"))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        pages.size
    }

    /** Additive restore: adds the backed-up documents next to the existing ones. */
    suspend fun restore(c: Context, input: InputStream): Int = withContext(Dispatchers.IO) {
        val d = dao(c)
        val pageMap = HashMap<Long, Page>()
        var restored = 0
        ZipInputStream(input.buffered()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "manifest.json") {
                    val m = JSONObject(String(z.readBytes()))
                    val fMap = HashMap<Long, Long>()
                    val fa = m.getJSONArray("folders")
                    for (i in 0 until fa.length()) fa.getJSONObject(i).let { fMap[it.getLong("id")] = d.insertFolder(Folder(name = it.getString("name"))) }
                    val dMap = HashMap<Long, Long>()
                    val da = m.getJSONArray("docs")
                    for (i in 0 until da.length()) da.getJSONObject(i).let {
                        dMap[it.getLong("id")] = d.insertDoc(
                            Doc(name = it.getString("name"), folderId = fMap[it.getLong("folderId")] ?: 0, created = it.getLong("created"),
                                favorite = it.getBoolean("favorite"), trashed = it.getBoolean("trashed"), ocrText = it.optString("ocr"))
                        )
                    }
                    val pa = m.getJSONArray("pages")
                    for (i in 0 until pa.length()) pa.getJSONObject(i).let {
                        val nd = dMap[it.getLong("docId")] ?: return@let
                        val p = Page(docId = nd, idx = it.getInt("idx"), rotation = it.getInt("rotation"), filter = it.getString("filter"),
                            brightness = it.getInt("brightness"), corners = it.getString("corners"))
                        pageMap[it.getLong("id")] = p.copy(id = d.insertPage(p))
                    }
                } else if (e.name.startsWith("pages/") && e.name.endsWith("_raw.jpg")) {
                    val old = e.name.removePrefix("pages/").removeSuffix("_raw.jpg").toLongOrNull()
                    val np = old?.let { pageMap[it] }
                    if (np != null) {
                        FileOutputStream(file(c, np.id, "raw")).use { z.copyTo(it) }
                        render(c, np); restored++
                    }
                }
                e = z.nextEntry
            }
        }
        restored
    }

    // ---------- OCR (offline Tesseract) ----------
    /** Returns null when no language data is installed. */
    suspend fun ocr(c: Context, docId: Long): String? = withContext(Dispatchers.Default) {
        val langs = Ocr.languages(c)
        if (langs.isEmpty()) return@withContext null
        val api = TessBaseAPI()
        if (!api.init(File(c.filesDir, "tess").path, langs.joinToString("+"))) { api.recycle(); return@withContext null }
        val sb = StringBuilder()
        for (p in dao(c).pages(docId)) {
            val b = ImageProc.decode(file(c, p.id, "out"), 2000) ?: continue
            api.setImage(b)
            sb.append(api.getUTF8Text()).append("\n\n")
            b.recycle()
        }
        api.recycle()
        dao(c).doc(docId)?.let { dao(c).updateDoc(it.copy(ocrText = sb.toString().trim())) }
        sb.toString().trim()
    }
}

object Ocr {
    fun dir(c: Context) = File(c.filesDir, "tess/tessdata").apply { mkdirs() }

    fun languages(c: Context): List<String> {
        val d = dir(c)
        try {
            c.assets.list("tessdata")?.forEach { n ->
                if (n.endsWith(".traineddata")) {
                    val t = File(d, n)
                    if (!t.exists()) c.assets.open("tessdata/$n").use { i -> t.outputStream().use { i.copyTo(it) } }
                }
            }
        } catch (e: Exception) { /* no bundled data */ }
        return d.listFiles()?.filter { it.name.endsWith(".traineddata") }?.map { it.name.removeSuffix(".traineddata") }
            ?.sortedBy { if (it == "eng") 0 else 1 } ?: emptyList()
    }

    fun importLang(c: Context, u: Uri): Boolean {
        val n = Repo.displayName(c, u)
        if (!n.endsWith(".traineddata")) return false
        c.contentResolver.openInputStream(u)?.use { i -> File(dir(c), n).outputStream().use { i.copyTo(it) } }
        return true
    }
}
