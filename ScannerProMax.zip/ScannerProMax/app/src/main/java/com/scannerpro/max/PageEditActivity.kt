package com.scannerpro.max

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PageEditActivity : AppCompatActivity() {
    private lateinit var page: Page
    private lateinit var iv: ImageView
    private lateinit var chipRow: android.widget.LinearLayout
    private var raw: Bitmap? = null
    private var filter = "MAGIC"
    private var bright = 0
    private var rot = 0
    private var job: Job? = null

    private val crop = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { loadPage() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.addView(header("Edit page"))
        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(C.LIGHT) }
        root.addView(iv, lp(-1, 0, 1f))

        chipRow = hbox().apply { setPadding(dp(8), dp(8), dp(8), 0) }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) })

        val bRow = hbox().apply { setPadding(dp(16), dp(4), dp(16), 0) }
        bRow.addView(label("Brightness", 13f, true), lp(-2, -2))
        val sb = SeekBar(this).apply {
            max = 200; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) { bright = p - 100; refresh() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bRow.addView(sb, lpm(0, -2, 1f, 8))
        root.addView(bRow)

        val row = hbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        row.addView(button("Rotate", false) { rot = (rot + 90) % 360; refresh() }, lpm(0, -2, 1f, 3))
        row.addView(button("Crop", false) {
            work("Saving…") {
                Repo.dao(this).updatePage(page.copy(filter = filter, brightness = bright, rotation = rot))
                crop.launch(Intent(this, CropActivity::class.java).putExtra("pageId", page.id))
            }
        }, lpm(0, -2, 1f, 3))
        row.addView(button("Save") { save() }, lpm(0, -2, 1f, 3))
        root.addView(row)
        setContentView(root)

        loadPage(sb)
        this.sb = sb
    }

    private var sb: SeekBar? = null

    private fun loadPage(seek: SeekBar? = sb) {
        lifecycleScope.launch {
            page = Repo.dao(this@PageEditActivity).page(intent.getLongExtra("pageId", 0L)) ?: run { finish(); return@launch }
            filter = page.filter; bright = page.brightness; rot = page.rotation
            seek?.progress = bright + 100
            raw = withContext(Dispatchers.Default) { ImageProc.decode(Repo.file(this@PageEditActivity, page.id, "raw"), 1400) }
            buildChips()
            refresh()
        }
    }

    private fun buildChips() {
        chipRow.removeAllViews()
        val chips = ImageProc.FILTERS.map { (id, name) ->
            Chip(this).apply { text = name; isCheckable = true; isChecked = id == filter; tag = id }
        }
        chips.forEach { ch ->
            ch.setOnClickListener {
                filter = ch.tag as String
                chips.forEach { it.isChecked = it === ch }
                refresh()
            }
            chipRow.addView(ch)
        }
    }

    private fun refresh() {
        val r = raw ?: return
        job?.cancel()
        job = lifecycleScope.launch {
            delay(100)
            val out = withContext(Dispatchers.Default) { ImageProc.process(r, page.corners, rot, filter, bright, 1100) }
            iv.setImageBitmap(out)
        }
    }

    private fun save() = work("Saving…") {
        val p = page.copy(filter = filter, brightness = bright, rotation = rot)
        Repo.dao(this).updatePage(p)
        Repo.render(this, p)
        setResult(RESULT_OK)
        finish()
    }
}
