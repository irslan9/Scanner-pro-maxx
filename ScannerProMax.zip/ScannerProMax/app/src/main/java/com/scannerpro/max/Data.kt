package com.scannerpro.max

import android.content.Context
import androidx.room.*

@Entity
data class Folder(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity
data class Doc(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val folderId: Long = 0,
    val created: Long = System.currentTimeMillis(),
    val favorite: Boolean = false,
    val trashed: Boolean = false,
    val ocrText: String = ""
)

@Entity
data class Page(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val docId: Long,
    val idx: Int,
    val rotation: Int = 0,
    val filter: String = "MAGIC",
    val brightness: Int = 0,
    val corners: String = ""
)

data class DocRow(@Embedded val doc: Doc, val pageCount: Int, val coverId: Long?)

@Dao
interface ScanDao {
    @Insert suspend fun insertDoc(d: Doc): Long
    @Insert suspend fun insertPage(p: Page): Long
    @Insert suspend fun insertFolder(f: Folder): Long
    @Update suspend fun updateDoc(d: Doc)
    @Update suspend fun updatePage(p: Page)
    @Update suspend fun updateFolder(f: Folder)
    @Delete suspend fun deleteDoc(d: Doc)
    @Delete suspend fun deletePage(p: Page)
    @Delete suspend fun deleteFolder(f: Folder)

    @Query("SELECT * FROM Doc WHERE id=:id") suspend fun doc(id: Long): Doc?
    @Query("SELECT * FROM Page WHERE id=:id") suspend fun page(id: Long): Page?
    @Query("SELECT * FROM Page WHERE docId=:docId ORDER BY idx") suspend fun pages(docId: Long): List<Page>
    @Query("SELECT COUNT(*) FROM Page WHERE docId=:docId") suspend fun pageCount(docId: Long): Int
    @Query("SELECT * FROM Folder ORDER BY name") suspend fun folders(): List<Folder>
    @Query("SELECT * FROM Doc") suspend fun allDocs(): List<Doc>
    @Query("SELECT * FROM Page") suspend fun allPages(): List<Page>
    @Query("UPDATE Doc SET folderId=0 WHERE folderId=:fid") suspend fun clearFolder(fid: Long)

    @Query(
        """SELECT d.*, 
        (SELECT COUNT(*) FROM Page WHERE docId=d.id) AS pageCount,
        (SELECT id FROM Page WHERE docId=d.id ORDER BY idx LIMIT 1) AS coverId
        FROM Doc d
        WHERE d.trashed=:trashed AND (:folder<0 OR d.folderId=:folder) AND (:fav=0 OR d.favorite=1)
        AND (d.name LIKE '%'||:q||'%' OR d.ocrText LIKE '%'||:q||'%')
        ORDER BY d.created DESC LIMIT :limit"""
    )
    suspend fun list(trashed: Boolean, folder: Long, fav: Int, q: String, limit: Int): List<DocRow>
}

@Database(entities = [Folder::class, Doc::class, Page::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ScanDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "scanner.db").build().also { inst = it }
        }
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun email(c: Context) = sp(c).getString("email", "") ?: ""
    fun setEmail(c: Context, v: String) = sp(c).edit().putString("email", v).apply()
    fun quality(c: Context) = sp(c).getInt("quality", 1)
    fun setQuality(c: Context, v: Int) = sp(c).edit().putInt("quality", v).apply()
    fun filter(c: Context) = sp(c).getString("filter", "MAGIC") ?: "MAGIC"
    fun setFilter(c: Context, v: String) = sp(c).edit().putString("filter", v).apply()
    fun auto(c: Context) = sp(c).getBoolean("auto", true)
    fun setAuto(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()
}
