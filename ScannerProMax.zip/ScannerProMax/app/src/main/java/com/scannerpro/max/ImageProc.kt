package com.scannerpro.max

import android.content.ContentResolver
import android.graphics.*
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import kotlin.math.*

/** Pure-algorithm image processing: no ML models, no OpenCV, fully offline. */
object ImageProc {
    val DEFAULT = floatArrayOf(0.04f, 0.04f, 0.96f, 0.04f, 0.96f, 0.96f, 0.04f, 0.96f)
    val FULL = floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)
    val FILTERS = listOf(
        "ORIGINAL" to "Original", "MAGIC" to "Magic colour", "BW" to "Black & white", "GRAY" to "Grayscale",
        "CLARITY" to "Clarity", "SHADOW" to "No shadows", "CONTRAST" to "Contrast", "SHARP" to "Sharpen text"
    )

    // ---------- decoding ----------
    fun fit(b: Bitmap, maxDim: Int): Bitmap {
        val m = max(b.width, b.height)
        return if (m <= maxDim) b else Bitmap.createScaledBitmap(b, b.width * maxDim / m, b.height * maxDim / m, true)
    }

    fun decode(f: File, maxDim: Int): Bitmap? {
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (max(o.outWidth, o.outHeight) / (s * 2) >= maxDim) s *= 2
        val b = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        return fit(b, maxDim)
    }

    fun decodeUpright(f: File, maxDim: Int): Bitmap? {
        val b = decode(f, maxDim) ?: return null
        val o = try { ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } catch (e: Exception) { 1 }
        return orient(b, o)
    }

    fun decodeUri(cr: ContentResolver, u: Uri, maxDim: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / (s * 2) >= maxDim) s *= 2
        val b = cr.openInputStream(u)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return null
        val ori = try {
            cr.openInputStream(u)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
        } catch (e: Exception) { 1 }
        return orient(fit(b, maxDim), ori)
    }

    private fun orient(b: Bitmap, o: Int) = rotate(b, when (o) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 })

    fun rotate(b: Bitmap, deg: Int): Bitmap =
        if (deg % 360 == 0) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

    // ---------- document edge detection ----------
    private fun lum(c: Int) = (((c shr 16) and 255) * 30 + ((c shr 8) and 255) * 59 + (c and 255) * 11) / 100

    fun parseCorners(s: String): FloatArray? {
        if (s.isBlank()) return null
        val p = s.split(",")
        return if (p.size == 8) FloatArray(8) { p[it].toFloat() } else null
    }

    fun detect(src: Bitmap): FloatArray = detectOrNull(src) ?: DEFAULT.copyOf()

    /** Returns corners TL,TR,BR,BL normalised 0..1, or null if no clear document was found. */
    fun detectOrNull(src: Bitmap): FloatArray? {
        val sc = 240f / max(src.width, src.height)
        val w = max(8, (src.width * sc).toInt())
        val h = max(8, (src.height * sc).toInt())
        val sm = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        sm.getPixels(px, 0, w, 0, 0, w, h)
        val g = IntArray(w * h) { lum(px[it]) }
        // Otsu threshold
        val hist = IntArray(256)
        g.forEach { hist[it]++ }
        var sum = 0L
        for (i in 0..255) sum += i.toLong() * hist[i]
        var wB = 0L; var sB = 0L; var best = 0.0; var th = 128
        val total = w * h
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0L) continue
            val wF = total - wB
            if (wF == 0L) break
            sB += t.toLong() * hist[t]
            val mB = sB.toDouble() / wB
            val mF = (sum - sB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; th = t }
        }
        for (pol in 0..1) {
            val b = blob(g, w, h) { if (pol == 0) it > th else it <= th } ?: continue
            val frac = b.first.toFloat() / total
            if (frac in 0.15f..0.95f && quadOk(b.second)) return b.second
        }
        return null
    }

    private fun quadOk(c: FloatArray): Boolean {
        var a = 0f
        for (i in 0..3) { val j = (i + 1) % 4; a += c[i * 2] * c[j * 2 + 1] - c[j * 2] * c[i * 2 + 1] }
        return abs(a) / 2 > 0.12f
    }

    /** Largest connected region of foreground pixels -> (area, corners). */
    private fun blob(g: IntArray, w: Int, h: Int, fg: (Int) -> Boolean): Pair<Int, FloatArray>? {
        val lab = BooleanArray(w * h)
        val stack = IntArray(w * h)
        var bestArea = 0
        var best: FloatArray? = null
        for (start in 0 until w * h) {
            if (lab[start] || !fg(g[start])) continue
            var sp = 0
            stack[sp++] = start; lab[start] = true
            var area = 0
            var tl = Int.MAX_VALUE; var br = Int.MIN_VALUE; var tr = Int.MIN_VALUE; var bl = Int.MAX_VALUE
            var tlP = 0; var brP = 0; var trP = 0; var blP = 0
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w; val y = p / w
                area++
                val a = x + y; val d = x - y
                if (a < tl) { tl = a; tlP = p }
                if (a > br) { br = a; brP = p }
                if (d > tr) { tr = d; trP = p }
                if (d < bl) { bl = d; blP = p }
                if (x > 0 && !lab[p - 1] && fg(g[p - 1])) { lab[p - 1] = true; stack[sp++] = p - 1 }
                if (x < w - 1 && !lab[p + 1] && fg(g[p + 1])) { lab[p + 1] = true; stack[sp++] = p + 1 }
                if (y > 0 && !lab[p - w] && fg(g[p - w])) { lab[p - w] = true; stack[sp++] = p - w }
                if (y < h - 1 && !lab[p + w] && fg(g[p + w])) { lab[p + w] = true; stack[sp++] = p + w }
            }
            if (area > bestArea) {
                bestArea = area
                fun nx(p: Int) = (p % w).toFloat() / (w - 1)
                fun ny(p: Int) = (p / w).toFloat() / (h - 1)
                best = floatArrayOf(nx(tlP), ny(tlP), nx(trP), ny(trP), nx(brP), ny(brP), nx(blP), ny(blP))
            }
        }
        return best?.let { bestArea to it }
    }

    // ---------- perspective correction ----------
    fun warp(src: Bitmap, c: FloatArray, maxDim: Int): Bitmap {
        val p = FloatArray(8) { if (it % 2 == 0) c[it] * src.width else c[it] * src.height }
        fun d(a: Int, b: Int) = hypot(p[a * 2] - p[b * 2], p[a * 2 + 1] - p[b * 2 + 1])
        var w = max(d(0, 1), d(3, 2))
        var h = max(d(0, 3), d(1, 2))
        val s = min(1f, maxDim / max(w, h))
        w *= s; h *= s
        val ow = max(1, w.toInt()); val oh = max(1, h.toInt())
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        m.setPolyToPoly(p, 0, floatArrayOf(0f, 0f, ow.toFloat(), 0f, ow.toFloat(), oh.toFloat(), 0f, oh.toFloat()), 0, 4)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** crop -> rotate -> filter. Never modifies [raw]. */
    fun process(raw: Bitmap, corners: String, rot: Int, filter: String, bright: Int, maxDim: Int): Bitmap {
        val cs = parseCorners(corners)
        var b = if (cs != null) warp(raw, cs, maxDim) else raw
        b = rotate(b, rot)
        return applyFilter(b, filter, bright)
    }

    // ---------- filters ----------
    private fun cm(src: Bitmap, m: ColorMatrix): Bitmap {
        val o = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(o).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        return o
    }

    private fun contrastM(c: Float): ColorMatrix {
        val t = (1 - c) * 127.5f
        return ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f))
    }

    fun applyFilter(src: Bitmap, f: String, br: Int): Bitmap {
        var o = when (f) {
            "MAGIC" -> cm(removeShadows(src), ColorMatrix().apply { setSaturation(1.25f); postConcat(contrastM(1.3f)) })
            "BW" -> blackWhite(src)
            "GRAY" -> cm(src, ColorMatrix().apply { setSaturation(0f) })
            "CLARITY" -> sharpen(removeShadows(src))
            "SHADOW" -> removeShadows(src)
            "CONTRAST" -> cm(src, contrastM(1.45f))
            "SHARP" -> sharpen(src)
            else -> src
        }
        if (br != 0) {
            val t = br * 1.6f
            o = cm(o, ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, t, 0f, 1f, 0f, 0f, t, 0f, 0f, 1f, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        }
        return o
    }

    /** Divides each pixel by an estimate of the paper colour (local max, blurred) -> flat, shadow-free page. */
    private fun removeShadows(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val sw = max(8, w / 12); val sh = max(8, h / 12)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val sp = IntArray(sw * sh)
        small.getPixels(sp, 0, sw, 0, 0, sw, sh)
        val bgS = IntArray(sw * sh)
        val r = 2
        for (y in 0 until sh) for (x in 0 until sw) {
            var mr = 0; var mg = 0; var mb = 0
            for (dy in -r..r) {
                val yy = (y + dy).coerceIn(0, sh - 1)
                for (dx in -r..r) {
                    val c = sp[yy * sw + (x + dx).coerceIn(0, sw - 1)]
                    mr = max(mr, (c shr 16) and 255); mg = max(mg, (c shr 8) and 255); mb = max(mb, c and 255)
                }
            }
            bgS[y * sw + x] = (0xFF shl 24) or (mr shl 16) or (mg shl 8) or mb
        }
        val bg = Bitmap.createScaledBitmap(Bitmap.createBitmap(bgS, sw, sh, Bitmap.Config.ARGB_8888), w, h, true)
        val a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h); bg.getPixels(b, 0, w, 0, 0, w, h)
        for (i in a.indices) {
            val c = a[i]; val k = b[i]
            val rr = min(255, ((c shr 16) and 255) * 255 / max(40, (k shr 16) and 255))
            val gg = min(255, ((c shr 8) and 255) * 255 / max(40, (k shr 8) and 255))
            val bb = min(255, (c and 255) * 255 / max(40, k and 255))
            a[i] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        o.setPixels(a, 0, w, 0, 0, w, h)
        return o
    }

    /** Adaptive (local-mean) threshold using an integral image. */
    private fun blackWhite(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val g = IntArray(w * h) { lum(px[it]) }
        val iw = w + 1
        val ii = IntArray(iw * (h + 1))
        for (y in 1..h) {
            var row = 0
            for (x in 1..w) { row += g[(y - 1) * w + x - 1]; ii[y * iw + x] = ii[(y - 1) * iw + x] + row }
        }
        val r = max(8, w / 32)
        for (y in 0 until h) {
            val y0 = max(0, y - r); val y1 = min(h, y + r + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - r); val x1 = min(w, x + r + 1)
                val s = ii[y1 * iw + x1] - ii[y0 * iw + x1] - ii[y1 * iw + x0] + ii[y0 * iw + x0]
                val n = (x1 - x0) * (y1 - y0)
                px[y * w + x] = if (g[y * w + x] * 10L * n < s.toLong() * 9) Color.BLACK else Color.WHITE
            }
        }
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        o.setPixels(px, 0, w, 0, 0, w, h)
        return o
    }

    private val SHIFTS = intArrayOf(16, 8, 0)

    private fun sharpen(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h)
        val o = a.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            var res = 0xFF shl 24
            for (s in SHIFTS) {
                val v = 5 * ((a[i] shr s) and 255) - ((a[i - 1] shr s) and 255) - ((a[i + 1] shr s) and 255) -
                    ((a[i - w] shr s) and 255) - ((a[i + w] shr s) and 255)
                res = res or (v.coerceIn(0, 255) shl s)
            }
            o[i] = res
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(o, 0, w, 0, 0, w, h)
        return out
    }
}
