package com.scannerpro.max

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

object DocActions {
    fun menu(a: AppCompatActivity, anchor: View, r: DocRow, refresh: () -> Unit) {
        val d = r.doc
        val dao = Repo.dao(a)
        val items = if (!d.trashed)
            listOf("Rename", if (d.favorite) "Remove favourite" else "Favourite", "Move to folder", "Share PDF", "Email PDF", "Move to trash")
        else listOf("Restore", "Delete forever")
        val pm = PopupMenu(a, anchor)
        items.forEachIndexed { i, s -> pm.menu.add(0, i, i, s) }
        pm.setOnMenuItemClickListener { mi ->
            when (items[mi.itemId]) {
                "Rename" -> a.input("Rename document", d.name) { n -> a.lifecycleScope.launch { dao.updateDoc(d.copy(name = n)); refresh() } }
                "Favourite", "Remove favourite" -> a.lifecycleScope.launch { dao.updateDoc(d.copy(favorite = !d.favorite)); refresh() }
                "Move to folder" -> move(a, d, refresh)
                "Share PDF" -> send(a, d, false)
                "Email PDF" -> send(a, d, true)
                "Move to trash" -> a.lifecycleScope.launch { dao.updateDoc(d.copy(trashed = true)); refresh() }
                "Restore" -> a.lifecycleScope.launch { dao.updateDoc(d.copy(trashed = false)); refresh() }
                "Delete forever" -> a.confirm("Delete \"${d.name}\" permanently?") { a.work("Deleting…") { Repo.purgeDoc(a, d.id); refresh() } }
            }
            true
        }
        pm.show()
    }

    private fun move(a: AppCompatActivity, d: Doc, refresh: () -> Unit) {
        a.lifecycleScope.launch {
            val fs = Repo.dao(a).folders()
            a.choose("Move to", listOf("No folder") + fs.map { it.name }) { i ->
                a.lifecycleScope.launch { Repo.dao(a).updateDoc(d.copy(folderId = if (i == 0) 0 else fs[i - 1].id)); refresh() }
            }
        }
    }

    private fun send(a: AppCompatActivity, d: Doc, email: Boolean) =
        a.work("Creating PDF…") { Repo.send(a, listOf(Repo.exportPdf(a, d.id, d.name, Prefs.quality(a))), email, d.name) }
}

class HomeFragment : Fragment() {
    private lateinit var recent: LinearLayout

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val m = requireActivity() as MainActivity
        val col = ctx.vbox(20)
        col.addView(ctx.label("Scanner Pro max", 28f, true))
        col.addView(ctx.label("Private · Offline · No ads", 13f, color = C.MUTED))
        col.addView(ctx.button("Scan Document") { m.scan() }.apply { textSize = 20f; minimumHeight = ctx.dp(76) }, ctx.lpm(-1, -2, 0f, 0).apply { topMargin = ctx.dp(20) })
        val row = ctx.hbox()
        row.addView(ctx.button("Import from Gallery", false) { m.importGallery() }, ctx.lpm(0, -2, 1f, 3))
        row.addView(ctx.button("Import PDF", false) { m.importPdf() }, ctx.lpm(0, -2, 1f, 3))
        col.addView(row)

        col.addView(ctx.label("PDF Tools", 18f, true).apply { setPadding(0, ctx.dp(20), 0, ctx.dp(6)) })
        val tools = ctx.hbox()
        tools.addView(ctx.button("Merge", false) { m.mergeMenu() }, ctx.lpm(0, -2, 1f, 3))
        tools.addView(ctx.button("Compress", false) { m.compressPdf() }, ctx.lpm(0, -2, 1f, 3))
        tools.addView(ctx.button("OCR", false) { m.ocrPick() }, ctx.lpm(0, -2, 1f, 3))
        col.addView(tools)

        val bk = ctx.card()
        val bv = ctx.vbox(14)
        bv.addView(ctx.label("Backup", 16f, true))
        bv.addView(ctx.label("Email PDFs to yourself, or save a full backup file you can restore later.", 13f, color = C.MUTED))
        bv.addView(ctx.button("Backup & Restore") { m.backupDialog() }, ctx.lpm(-1, -2, 0f, 0).apply { topMargin = ctx.dp(8) })
        bk.addView(bv)
        col.addView(bk, ctx.lpm(-1, -2, 0f, 0).apply { topMargin = ctx.dp(16) })

        col.addView(ctx.label("Recent Documents", 18f, true).apply { setPadding(0, ctx.dp(20), 0, ctx.dp(6)) })
        recent = ctx.vbox()
        col.addView(recent)
        return ScrollView(ctx).apply { addView(col) }
    }

    override fun onResume() {
        super.onResume()
        val ctx = requireContext()
        val m = requireActivity() as MainActivity
        viewLifecycleOwner.lifecycleScope.launch {
            val scope = this
            val rows = Repo.dao(ctx).list(false, -1, 0, "", 5)
            recent.removeAllViews()
            if (rows.isEmpty()) recent.addView(ctx.label("No documents yet. Tap Scan Document to start.", 14f, color = C.MUTED))
            rows.forEach { r ->
                recent.addView(ctx.docItem(r, false, scope, { m.openDoc(r.doc.id) }, { v -> DocActions.menu(m, v, r) { onResume() } }), ctx.lpm(-1, -2, 0f, 4))
            }
        }
    }
}

class DocsFragment : Fragment() {
    private var mode = 0 // 0 all, 1 favourites, 2 trash, 3 folder
    private var folderId = 0L
    private var grid = true
    private var query = ""
    private lateinit var rv: RecyclerView
    private lateinit var chips: LinearLayout
    private lateinit var empty: TextView
    private lateinit var toggle: TextView
    private val adapter = Adapter()
    private fun m() = requireActivity() as MainActivity

    private inner class Adapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var rows = listOf<DocRow>()
        override fun getItemCount() = rows.size
        override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
            val f = FrameLayout(p.context).apply {
                layoutParams = RecyclerView.LayoutParams(-1, -2)
                setPadding(p.context.dp(4), p.context.dp(4), p.context.dp(4), p.context.dp(4))
            }
            return object : RecyclerView.ViewHolder(f) {}
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
            val f = h.itemView as FrameLayout
            f.removeAllViews()
            val r = rows[i]
            f.addView(f.context.docItem(r, grid, viewLifecycleOwner.lifecycleScope, { m().openDoc(r.doc.id) }, { v -> DocActions.menu(m(), v, r) { refresh() } }))
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val col = ctx.vbox(12)
        val top = ctx.hbox()
        val search = EditText(ctx).apply {
            hint = "Search names and recognised text"; setSingleLine(); textSize = 14f
            setBackgroundColor(C.LIGHT); setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { query = s.toString().trim(); refresh() }
            })
        }
        top.addView(search, lp(0, -2, 1f))
        toggle = ctx.label("☰", 24f, true).apply {
            setPadding(ctx.dp(14), 0, ctx.dp(6), 0)
            setOnClickListener { grid = !grid; applyLayout(); adapter.notifyDataSetChanged() }
        }
        top.addView(toggle)
        col.addView(top)
        chips = ctx.hbox()
        col.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
        empty = ctx.label("Nothing here yet.", 14f, color = C.MUTED).apply { setPadding(0, ctx.dp(24), 0, 0) }
        col.addView(empty)
        rv = RecyclerView(ctx).apply { adapter = this@DocsFragment.adapter }
        applyLayout()
        col.addView(rv, lp(-1, 0, 1f))
        return col
    }

    private fun applyLayout() {
        rv.layoutManager = GridLayoutManager(requireContext(), if (grid) 2 else 1)
        toggle.text = if (grid) "☰" else "▦"
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        if (!isAdded) return
        val ctx = requireContext()
        viewLifecycleOwner.lifecycleScope.launch {
            val d = Repo.dao(ctx)
            val folders = d.folders()
            val rows = d.list(mode == 2, if (mode == 3) folderId else -1, if (mode == 1) 1 else 0, query, 500)
            buildChips(folders)
            adapter.rows = rows
            adapter.notifyDataSetChanged()
            empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun buildChips(folders: List<Folder>) {
        val ctx = requireContext()
        chips.removeAllViews()
        fun chip(t: String, sel: Boolean, long: (() -> Unit)? = null, click: () -> Unit) {
            chips.addView(Chip(ctx).apply {
                text = t; isCheckable = true; isChecked = sel
                setOnClickListener { click() }
                if (long != null) setOnLongClickListener { long(); true }
            })
        }
        chip("All", mode == 0) { mode = 0; refresh() }
        chip("★ Favourites", mode == 1) { mode = 1; refresh() }
        chip("Trash", mode == 2) { mode = 2; refresh() }
        folders.forEach { f ->
            chip("📁 ${f.name}", mode == 3 && folderId == f.id, {
                ctx.choose(f.name, listOf("Rename folder", "Delete folder")) { i ->
                    if (i == 0) ctx.input("Rename folder", f.name) { n -> viewLifecycleOwner.lifecycleScope.launch { Repo.dao(ctx).updateFolder(f.copy(name = n)); refresh() } }
                    else viewLifecycleOwner.lifecycleScope.launch {
                        Repo.dao(ctx).clearFolder(f.id); Repo.dao(ctx).deleteFolder(f)
                        if (folderId == f.id) mode = 0
                        refresh()
                    }
                }
            }) { mode = 3; folderId = f.id; refresh() }
        }
        chip("+ Folder", false) {
            ctx.input("New folder", "") { n -> viewLifecycleOwner.lifecycleScope.launch { Repo.dao(ctx).insertFolder(Folder(name = n)); refresh() } }
        }
    }
}

class ToolsFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val m = requireActivity() as MainActivity
        val col = ctx.vbox(16)
        col.addView(ctx.label("Tools", 26f, true))
        val items = listOf<Triple<String, String, () -> Unit>>(
            Triple("Import images", "Make a document from photos in your gallery", { m.importGallery() }),
            Triple("Import PDF", "Turn a PDF into editable pages", { m.importPdf() }),
            Triple("Merge", "Combine scanned documents or PDF files into one", { m.mergeMenu() }),
            Triple("Compress PDF", "Shrink a PDF and choose the quality", { m.compressPdf() }),
            Triple("Email documents", "Pick several documents and send them by email", { m.emailDocs() }),
            Triple("Extract text (OCR)", "Read text from a document, offline", { m.ocrPick() }),
            Triple("Create backup file", "Save everything into one .zip file", { m.createBackup() }),
            Triple("Restore backup", "Add documents from a backup .zip", { m.restoreBackup() })
        )
        items.forEach { (t, d, act) ->
            val cd = ctx.card().apply { setOnClickListener { act() } }
            val v = ctx.vbox(14)
            v.addView(ctx.label(t, 16f, true))
            v.addView(ctx.label(d, 13f, color = C.MUTED))
            cd.addView(v)
            col.addView(cd, ctx.lpm(-1, -2, 0f, 5))
        }
        return ScrollView(ctx).apply { addView(col) }
    }
}

class SettingsFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        val m = requireActivity() as MainActivity
        val col = ctx.vbox(16)
        col.addView(ctx.label("Settings", 26f, true))

        col.addView(ctx.label("Email address for backups", 14f, true).apply { setPadding(0, ctx.dp(16), 0, ctx.dp(4)) })
        val et = EditText(ctx).apply {
            setText(Prefs.email(ctx)); hint = "you@example.com"; setSingleLine()
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }
        col.addView(et)
        col.addView(ctx.button("Save email") { Prefs.setEmail(ctx, et.text.toString().trim()); ctx.toast("Saved") })
        col.addView(ctx.label("Used only to pre-fill the recipient in your email app. No passwords are ever stored.", 12f, color = C.MUTED))

        val q = listOf("High", "Medium", "Smallest")
        val qb = ctx.button("Default PDF quality: ${q[Prefs.quality(ctx)]}", false) {}
        qb.setOnClickListener { ctx.choose("PDF quality", q) { Prefs.setQuality(ctx, it); qb.text = "Default PDF quality: ${q[it]}" } }
        col.addView(qb, ctx.lpm(-1, -2, 0f, 0).apply { topMargin = ctx.dp(16) })

        val fb = ctx.button("Default filter: ${ImageProc.FILTERS.first { it.first == Prefs.filter(ctx) }.second}", false) {}
        fb.setOnClickListener {
            ctx.choose("Default filter", ImageProc.FILTERS.map { it.second }) { i ->
                Prefs.setFilter(ctx, ImageProc.FILTERS[i].first); fb.text = "Default filter: ${ImageProc.FILTERS[i].second}"
            }
        }
        col.addView(fb, ctx.lpm(-1, -2, 0f, 0).apply { topMargin = ctx.dp(8) })

        val sw = MaterialSwitch(ctx).apply {
            text = "Auto-capture when the document is steady"; isChecked = Prefs.auto(ctx)
            setOnCheckedChangeListener { _, on -> Prefs.setAuto(ctx, on) }
        }
        col.addView(sw, ctx.lpm(-1, -2, 0f, 0).apply { topMargin = ctx.dp(12) })

        col.addView(ctx.label("OCR languages", 14f, true).apply { setPadding(0, ctx.dp(20), 0, ctx.dp(4)) })
        val langs = Ocr.languages(ctx)
        col.addView(ctx.label(if (langs.isEmpty()) "None installed" else "Installed: ${langs.joinToString(", ")}", 13f, color = C.MUTED))
        col.addView(ctx.button("Import OCR language file", false) { m.importLang() })

        col.addView(ctx.label("Privacy", 14f, true).apply { setPadding(0, ctx.dp(20), 0, ctx.dp(4)) })
        col.addView(ctx.label("Documents are stored only in this app's private storage. Nothing is uploaded, there is no account, no ads and no tracking. Sharing and email only happen when you choose them.", 13f, color = C.MUTED))
        return ScrollView(ctx).apply { addView(col) }
    }
}
