package com.scannerpro.max

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private var pdfMode = "import"
    private var pendingSave: File? = null

    private val pickImages = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { importImages(it) }
    private val pickPdfs = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { handlePdfs(it) }
    private val makeBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u -> if (u != null) doBackup(u) }
    private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) doRestore(u) }
    private val saveLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { u ->
        val f = pendingSave
        if (u != null && f != null) work("Saving…") { Repo.copyTo(this, f, u); toast("PDF saved") }
    }
    private val pickLang = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) toast(if (Ocr.importLang(this, u)) "OCR language added" else "Choose a .traineddata file")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        root.addView(FrameLayout(this).apply { id = R.id.container }, lp(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply { inflateMenu(R.menu.nav); setBackgroundColor(Color.WHITE) }
        root.addView(nav, lp(-1, -2))
        setContentView(root)
        nav.setOnItemSelectedListener { item ->
            if (item.itemId == R.id.n_scan) {
                startActivity(Intent(this, ScanActivity::class.java)); false
            } else {
                val f = when (item.itemId) {
                    R.id.n_home -> HomeFragment()
                    R.id.n_docs -> DocsFragment()
                    R.id.n_tools -> ToolsFragment()
                    else -> SettingsFragment()
                }
                supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
                true
            }
        }
        if (savedInstanceState == null) nav.selectedItemId = R.id.n_home
    }

    // ---------- actions used by the fragments ----------
    fun scan() = startActivity(Intent(this, ScanActivity::class.java))
    fun openDoc(id: Long) = startActivity(Intent(this, DocActivity::class.java).putExtra("docId", id))
    fun importGallery() = pickImages.launch("image/*")
    fun importPdf() { pdfMode = "import"; pickPdfs.launch(arrayOf("application/pdf")) }
    fun mergePdfFiles() { pdfMode = "merge"; pickPdfs.launch(arrayOf("application/pdf")) }
    fun compressPdf() { pdfMode = "compress"; pickPdfs.launch(arrayOf("application/pdf")) }
    fun importLang() = pickLang.launch(arrayOf("*/*"))

    fun mergeMenu() = choose("Merge", listOf("Merge scanned documents", "Merge PDF files")) { if (it == 0) mergeDocs() else mergePdfFiles() }

    fun backupDialog() = choose("Backup", listOf("Email selected PDFs", "Create backup file (.zip)", "Restore from backup file")) {
        when (it) { 0 -> emailDocs(); 1 -> createBackup(); else -> openBackup.launch(arrayOf("*/*")) }
    }

    fun createBackup() = makeBackup.launch("ScannerProMax-backup-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".zip")
    fun restoreBackup() = openBackup.launch(arrayOf("*/*"))

    private fun doBackup(u: Uri) = work("Creating backup…") {
        val out = contentResolver.openOutputStream(u) ?: throw IllegalStateException("Cannot write file")
        val n = Repo.backup(this, out)
        toast("Backed up $n pages")
    }

    private fun doRestore(u: Uri) = work("Restoring…") {
        val i = contentResolver.openInputStream(u) ?: throw IllegalStateException("Cannot read file")
        val n = Repo.restore(this, i)
        toast("Restored $n pages")
    }

    private fun importImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        work("Importing…") {
            val id = Repo.newDoc(this)
            uris.forEach { u -> ImageProc.decodeUri(contentResolver, u, 3000)?.let { Repo.addPage(this, id, it) } }
            openDoc(id)
        }
    }

    private fun handlePdfs(uris: List<Uri>) {
        if (uris.isEmpty()) return
        when (pdfMode) {
            "compress" -> compress(uris[0])
            "merge" -> work("Merging PDFs…") {
                val id = Repo.newDoc(this, "Merged PDF " + SimpleDateFormat("HH.mm", Locale.US).format(Date()))
                uris.forEach { Repo.importPdf(this, it, id) }
                openDoc(id)
            }
            else -> work("Importing PDF…") {
                var last = 0L
                uris.forEach { u ->
                    last = Repo.newDoc(this, Repo.displayName(this, u).removeSuffix(".pdf"))
                    Repo.importPdf(this, u, last)
                }
                openDoc(last)
            }
        }
    }

    private fun compress(u: Uri) = choose("Compression level", listOf("High quality", "Medium", "Smallest file")) { q ->
        work("Compressing…") {
            val before = Repo.size(this, u)
            val tmp = Repo.newDoc(this, "tmp")
            Repo.importPdf(this, u, tmp)
            val f = Repo.exportPdf(this, tmp, Repo.displayName(this, u).removeSuffix(".pdf") + "-compressed", q)
            Repo.purgeDoc(this, tmp)
            MaterialAlertDialogBuilder(this).setTitle("Done")
                .setMessage("Original: ${Repo.human(before)}\nCompressed: ${Repo.human(f.length())}")
                .setPositiveButton("Share") { _, _ -> Repo.send(this, listOf(f), false, f.name) }
                .setNeutralButton("Save to device") { _, _ -> pendingSave = f; saveLauncher.launch(f.name) }
                .setNegativeButton("Close", null).show()
        }
    }

    /** Multi-select dialog of documents; returns ids in list order. */
    private fun pickDocs(title: String, multi: Boolean, cb: (List<Long>) -> Unit) {
        lifecycleScope.launch {
            val rows = Repo.dao(this@MainActivity).list(false, -1, 0, "", 1000)
            if (rows.isEmpty()) { toast("No documents yet"); return@launch }
            val names = rows.map { it.doc.name + " (${it.pageCount}p)" }.toTypedArray()
            if (!multi) {
                MaterialAlertDialogBuilder(this@MainActivity).setTitle(title).setItems(names) { _, i -> cb(listOf(rows[i].doc.id)) }.show()
                return@launch
            }
            val checked = BooleanArray(rows.size)
            MaterialAlertDialogBuilder(this@MainActivity).setTitle(title)
                .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
                .setPositiveButton("OK") { _, _ ->
                    val ids = rows.filterIndexed { i, _ -> checked[i] }.map { it.doc.id }
                    if (ids.isEmpty()) toast("Nothing selected") else cb(ids)
                }
                .setNegativeButton("Cancel", null).show()
        }
    }

    fun mergeDocs() = pickDocs("Select documents to merge", true) { ids ->
        if (ids.size < 2) { toast("Select at least two"); return@pickDocs }
        work("Merging…") { openDoc(Repo.mergeDocs(this, ids, "Merged " + SimpleDateFormat("HH.mm", Locale.US).format(Date()))) }
    }

    fun emailDocs() = pickDocs("Select documents to email", true) { ids ->
        work("Creating PDFs…") {
            val files = ids.map { id ->
                val d = Repo.dao(this).doc(id)!!
                Repo.exportPdf(this, id, d.name, Prefs.quality(this))
            }
            Repo.send(this, files, true, if (files.size == 1) files[0].nameWithoutExtension else "Scanned documents")
        }
    }

    fun ocrPick() = pickDocs("Extract text from…", false) { runOcr(it[0]) }

    fun runOcr(docId: Long) = work("Reading text (offline)…") {
        val t = Repo.ocr(this, docId)
        if (t == null) showText("OCR not set up",
            "No OCR language data found.\n\nSettings → Import OCR language file, and choose eng.traineddata (and urd.traineddata for Urdu) from github.com/tesseract-ocr/tessdata_fast.")
        else showText("Recognised text", t.ifBlank { "(no text found)" })
    }
}
