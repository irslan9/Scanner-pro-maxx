package com.scannerpro.max

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

object C {
    val NAVY = Color.parseColor("#0B2A5B")
    val LIGHT = Color.parseColor("#DCEBFB")
    val ACCENT = Color.parseColor("#2F6FDB")
    val MUTED = Color.parseColor("#5B6B82")
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun lp(w: Int = -1, h: Int = -2, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun Context.lpm(w: Int = -1, h: Int = -2, weight: Float = 0f, m: Int = 4) =
    LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(m), dp(m), dp(m), dp(m)) }

fun Context.label(s: String, size: Float = 14f, bold: Boolean = false, color: Int = C.NAVY) = TextView(this).apply {
    text = s; textSize = size; setTextColor(color)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.button(s: String, filled: Boolean = true, onClick: () -> Unit): MaterialButton =
    (if (filled) MaterialButton(this) else MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)).apply {
        text = s; isAllCaps = false; cornerRadius = dp(14); setOnClickListener { onClick() }
    }

fun Context.card() = MaterialCardView(this).apply {
    radius = dp(16).toFloat(); cardElevation = 0f; strokeWidth = dp(1); strokeColor = C.LIGHT; setCardBackgroundColor(Color.WHITE)
}

fun Context.vbox(pad: Int = 0) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
}

fun Context.hbox() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

fun Activity.busy(msg: String): AlertDialog {
    val ctx = this
    val b = hbox().apply {
        setPadding(dp(24), dp(20), dp(24), dp(20))
        addView(ProgressBar(ctx), lp(dp(32), dp(32)))
        addView(ctx.label("  $msg", 15f), lp(-2, -2))
    }
    return MaterialAlertDialogBuilder(this).setView(b).setCancelable(false).show()
}

/** Runs [block] on the main thread with a progress dialog; errors are shown instead of crashing. */
fun AppCompatActivity.work(msg: String, block: suspend () -> Unit) {
    val d = busy(msg)
    lifecycleScope.launch {
        try { block() } catch (e: Exception) { toast("Error: ${e.message}") } finally { d.dismiss() }
    }
}

fun Context.input(title: String, initial: String, ok: (String) -> Unit) {
    val et = EditText(this).apply { setText(initial); setSingleLine(); setSelectAllOnFocus(true) }
    val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) }
    MaterialAlertDialogBuilder(this).setTitle(title).setView(wrap)
        .setPositiveButton("OK") { _, _ -> val s = et.text.toString().trim(); if (s.isNotEmpty()) ok(s) }
        .setNegativeButton("Cancel", null).show()
}

fun Context.choose(title: String, items: List<String>, onPick: (Int) -> Unit) {
    MaterialAlertDialogBuilder(this).setTitle(title).setItems(items.toTypedArray()) { _, i -> onPick(i) }.show()
}

fun Context.confirm(msg: String, ok: () -> Unit) {
    MaterialAlertDialogBuilder(this).setMessage(msg).setPositiveButton("Yes") { _, _ -> ok() }.setNegativeButton("Cancel", null).show()
}

fun Context.showText(title: String, text: String, extra: Pair<String, () -> Unit>? = null) {
    val tv = label(text, 14f, color = Color.BLACK).apply { setTextIsSelectable(true); setPadding(dp(20), dp(8), dp(20), dp(8)) }
    val b = MaterialAlertDialogBuilder(this).setTitle(title).setView(ScrollView(this).apply { addView(tv) })
        .setPositiveButton("Copy") { _, _ ->
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", text))
            toast("Copied")
        }
        .setNegativeButton("Close", null)
    if (extra != null) b.setNeutralButton(extra.first) { _, _ -> extra.second() }
    b.show()
}

fun AppCompatActivity.header(title: String): LinearLayout {
    val ctx = this
    return hbox().apply {
        setPadding(dp(8), dp(8), dp(8), dp(8))
        addView(ctx.label("←", 24f, true).apply { setPadding(dp(12), dp(4), dp(12), dp(4)); setOnClickListener { finish() } })
        addView(ctx.label(title, 18f, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, lp(0, -2, 1f))
    }
}

fun loadThumb(iv: ImageView, f: File, scope: CoroutineScope) {
    iv.setImageDrawable(null)
    if (!f.exists()) return
    scope.launch {
        val b = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(f.path) }
        if (b != null) iv.setImageBitmap(b)
    }
}

/** Shared document row/card used by Home and Documents (grid = vertical card, else list row). */
fun Context.docItem(r: DocRow, grid: Boolean, scope: CoroutineScope, onOpen: () -> Unit, onMenu: (View) -> Unit): View {
    val ctx = this
    val card = card().apply { setOnClickListener { onOpen() } }
    val root = LinearLayout(this).apply {
        orientation = if (grid) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        setPadding(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
        gravity = if (grid) Gravity.START else Gravity.CENTER_VERTICAL
    }
    val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(C.LIGHT) }
    root.addView(iv, if (grid) lp(-1, dp(150)) else lp(dp(60), dp(80)))
    r.coverId?.let { loadThumb(iv, Repo.file(this, it, "thumb"), scope) }

    val info = vbox().apply { setPadding(if (grid) 0 else ctx.dp(12), ctx.dp(8), 0, 0) }
    val top = hbox()
    top.addView(label(r.doc.name, 15f, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }, lp(0, -2, 1f))
    if (r.doc.favorite) top.addView(label("★", 16f, color = C.ACCENT))
    top.addView(label("⋮", 20f).apply { setPadding(ctx.dp(10), 0, ctx.dp(4), 0); setOnClickListener { onMenu(it) } })
    info.addView(top)
    info.addView(label("${Repo.fmt(r.doc.created)} · ${r.pageCount} page${if (r.pageCount == 1) "" else "s"}", 12f, color = C.MUTED))
    root.addView(info, if (grid) lp(-1, -2) else lp(0, -2, 1f))
    card.addView(root)
    return card
}
