package com.scannerpro.max

import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot
import kotlin.math.min

class CornerView(c: Context) : View(c) {
    var bmp: Bitmap? = null
    var pts: FloatArray = ImageProc.DEFAULT.copyOf()
    private var drag = -1
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2F6FDB.toInt(); style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x442F6FDB; style = Paint.Style.FILL }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val path = Path()

    private fun rect(): RectF {
        val b = bmp ?: return RectF()
        val s = min(width / b.width.toFloat(), height / b.height.toFloat())
        val w = b.width * s; val h = b.height * s
        return RectF((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        val r = rect()
        canvas.drawBitmap(b, null, r, null)
        path.reset()
        path.moveTo(r.left + pts[0] * r.width(), r.top + pts[1] * r.height())
        for (i in 1..3) path.lineTo(r.left + pts[i * 2] * r.width(), r.top + pts[i * 2 + 1] * r.height())
        path.close()
        canvas.drawPath(path, fill); canvas.drawPath(path, line)
        for (i in 0..3) {
            val x = r.left + pts[i * 2] * r.width(); val y = r.top + pts[i * 2 + 1] * r.height()
            canvas.drawCircle(x, y, 13 * d, dot); canvas.drawCircle(x, y, 13 * d, line)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val r = rect()
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                var best = 56 * d
                drag = -1
                for (i in 0..3) {
                    val dist = hypot(e.x - (r.left + pts[i * 2] * r.width()), e.y - (r.top + pts[i * 2 + 1] * r.height()))
                    if (dist < best) { best = dist; drag = i }
                }
                return drag >= 0
            }
            MotionEvent.ACTION_MOVE -> if (drag >= 0 && r.width() > 0) {
                pts[drag * 2] = ((e.x - r.left) / r.width()).coerceIn(0f, 1f)
                pts[drag * 2 + 1] = ((e.y - r.top) / r.height()).coerceIn(0f, 1f)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = -1
        }
        return true
    }
}

class CropActivity : AppCompatActivity() {
    private lateinit var cv: CornerView
    private lateinit var page: Page

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pid = intent.getLongExtra("pageId", 0L)
        cv = CornerView(this)
        val root = vbox()
        root.addView(header("Adjust corners"))
        root.addView(cv, lp(-1, 0, 1f))
        val row = hbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        row.addView(button("Auto", false) {
            cv.bmp?.let { cv.pts = ImageProc.detect(it); cv.invalidate() }
        }, lpm(0, -2, 1f, 3))
        row.addView(button("Full page", false) { cv.pts = ImageProc.FULL.copyOf(); cv.invalidate() }, lpm(0, -2, 1f, 3))
        row.addView(button("Apply") { applyCrop() }, lpm(0, -2, 1f, 3))
        root.addView(row)
        setContentView(root)

        lifecycleScope.launch {
            page = Repo.dao(this@CropActivity).page(pid) ?: run { finish(); return@launch }
            cv.bmp = withContext(Dispatchers.Default) { ImageProc.decode(Repo.file(this@CropActivity, pid, "raw"), 1600) }
            cv.pts = ImageProc.parseCorners(page.corners) ?: ImageProc.FULL.copyOf()
            cv.invalidate()
        }
    }

    private fun applyCrop() = work("Applying…") {
        val p = page.copy(corners = cv.pts.joinToString(","))
        Repo.dao(this).updatePage(p)
        Repo.render(this, p)
        setResult(RESULT_OK)
        finish()
    }
}
