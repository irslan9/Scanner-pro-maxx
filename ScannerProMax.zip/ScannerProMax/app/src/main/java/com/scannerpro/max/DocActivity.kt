package com.scannerpro.max

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File

class DocActivity : AppCompatActivity() {
    private var docId = 0L
    private var doc: Doc? = null
    private var pages = listOf<Page>()
    private var pendingFile: File? = null
    private lateinit var titleTv: TextView
    private lateinit var sub: TextView
    private lateinit var rv: RecyclerView
    private val adapter = PageAdapter()

    private val save = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { u ->
        val f = pendingFile
        if (u != null && f != null) work("Saving…") { Repo.copyTo(this, f, u); toast("PDF saved") }
    }
    private val edit = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { reload() }
    private val gallery = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) work("Importing…") {
            uris.forEach { u -> ImageProc.decodeUri(contentResolver, u, 3000)?.let { Repo.addPage(this, docId, it) } }
            reload()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        docId = intent.getLongExtra("docId", 0L)
        val root = vbox()
        val head = header("")
        titleTv = head.getChildAt(1) as TextView
        titleTv.setOnClickListener { doc?.let { d -> input("Rename document", d.name) { n -> lifecycleScope.launch { Repo.dao(this@DocActivity).updateDoc(d.copy(name = n)); reload() } } } }
        root.addView(head)
        sub = label("", 12f, color = C.MUTED).apply { setPadding(dp(20), 0, dp(20), dp(4)) }
        root.addView(sub)
        rv = RecyclerView(this).apply { layoutManager = GridLayoutManager(this@DocActivity, 2); adapter = this@DocActivity.adapter }
        root.addView(rv, lp(-1, 0, 1f))

        val bar = hbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        bar.addView(button("+ Scan", false) { startActivity(Intent(this, ScanActivity::class.java).putExtra("docId", docId)) }, lpm(0, -2, 1f, 2))
        bar.addView(button("Gallery", false) { gallery.launch("image/*") }, lpm(0, -2, 1f, 2))
        bar.addView(button("Text", false) { showOcr() }, lpm(0, -2, 1f, 2))
        bar.addView(button("PDF") { exportDialog() }, lpm(0, -2, 1f, 2))
        root.addView(bar)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); reload() }

    private fun reload() {
        lifecycleScope.launch {
            val dao = Repo.dao(this@DocActivity)
            val d = dao.doc(docId) ?: run { finish(); return@launch }
            doc = d
            pages = dao.pages(docId)
            titleTv.text = d.name
            sub.text = "${pages.size} page${if (pages.size == 1) "" else "s"} · ${Repo.fmt(d.created)} · tap the title to rename"
            adapter.notifyDataSetChanged()
        }
    }

    private inner class PageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = pages.size
        override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
            val f = FrameLayout(p.context).apply {
                layoutParams = RecyclerView.LayoutParams(-1, -2)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            return object : RecyclerView.ViewHolder(f) {}
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
            val f = h.itemView as FrameLayout
            f.removeAllViews()
            f.addView(pageView(pages[i], i))
        }
    }

    private fun pageView(p: Page, i: Int): View {
        val card = card()
        val col = vbox(8)
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(C.LIGHT); setOnClickListener { openEdit(p) } }
        col.addView(iv, lp(-1, dp(220)))
        loadThumb(iv, Repo.file(this, p.id, "thumb"), lifecycleScope)
        col.addView(label("Page ${i + 1}", 12f, color = C.MUTED).apply { setPadding(0, dp(4), 0, 0) })
        val row = hbox()
        fun b(t: String, act: () -> Unit) {
            row.addView(TextView(this).apply {
                text = t; textSize = 18f; setTextColor(C.NAVY); gravity = Gravity.CENTER
                setPadding(dp(2), dp(8), dp(2), dp(8)); setOnClickListener { act() }
            }, lp(0, -2, 1f))
        }
        b("◀") { move(i, -1) }
        b("▶") { move(i, 1) }
        b("⟳") { rotate(p) }
        b("✎") { openEdit(p) }
        b("✕") { confirm("Delete page ${i + 1}?") { work("Deleting…") { Repo.deletePage(this, p); reload() } } }
        col.addView(row)
        card.addView(col)
        return card
    }

    private fun openEdit(p: Page) = edit.launch(Intent(this, PageEditActivity::class.java).putExtra("pageId", p.id))

    private fun move(i: Int, d: Int) {
        val j = i + d
        if (j !in pages.indices) return
        lifecycleScope.launch {
            val dao = Repo.dao(this@DocActivity)
            val a = pages[i]; val b = pages[j]
            dao.updatePage(a.copy(idx = b.idx)); dao.updatePage(b.copy(idx = a.idx))
            reload()
        }
    }

    private fun rotate(p: Page) = work("Rotating…") {
        val np = p.copy(rotation = (p.rotation + 90) % 360)
        Repo.dao(this).updatePage(np)
        Repo.render(this, np)
        reload()
    }

    private fun showOcr() {
        val d = doc ?: return
        if (d.ocrText.isNotBlank()) showText("Recognised text", d.ocrText, "Run again" to { runOcr() }) else runOcr()
    }

    private fun runOcr() = work("Reading text (offline)…") {
        val t = Repo.ocr(this, docId)
        if (t == null) showText("OCR not set up",
            "No OCR language data found.\n\nSettings → Import OCR language file, and choose eng.traineddata (and urd.traineddata for Urdu) from github.com/tesseract-ocr/tessdata_fast.")
        else showText("Recognised text", t.ifBlank { "(no text found)" })
        reload()
    }

    private fun exportDialog() {
        val d = doc ?: return
        val col = vbox(20)
        val et = EditText(this).apply { setText(d.name); setSingleLine(); setSelectAllOnFocus(true) }
        col.addView(label("File name", 13f, true))
        col.addView(et)
        col.addView(label("Quality", 13f, true).apply { setPadding(0, dp(12), 0, 0) })
        val rg = RadioGroup(this)
        listOf("High (largest)", "Medium", "Smallest file").forEachIndexed { i, s ->
            rg.addView(RadioButton(this).apply { text = s; id = 100 + i; isChecked = i == Prefs.quality(this@DocActivity) })
        }
        col.addView(rg)
        fun run(action: (File) -> Unit) {
            val name = et.text.toString().trim().ifBlank { d.name }
            val q = (rg.checkedRadioButtonId - 100).coerceIn(0, 2)
            work("Creating PDF…") {
                val f = Repo.exportPdf(this, docId, name, q)
                toast("${f.name} · ${Repo.human(f.length())}")
                action(f)
            }
        }
        MaterialAlertDialogBuilder(this).setTitle("Export PDF").setView(col)
            .setPositiveButton("Share") { _, _ -> run { Repo.send(this, listOf(it), false, d.name) } }
            .setNeutralButton("Email") { _, _ -> run { Repo.send(this, listOf(it), true, d.name) } }
            .setNegativeButton("Save to device") { _, _ -> run { pendingFile = it; save.launch(it.name) } }
            .show()
    }
}
