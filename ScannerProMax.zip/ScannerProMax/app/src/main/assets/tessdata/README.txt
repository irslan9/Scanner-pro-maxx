OPTIONAL (for OCR): put eng.traineddata and urd.traineddata here before building
(download from https://github.com/tesseract-ocr/tessdata_fast).
You can also skip this and import the files later from Settings > Import OCR language file.
